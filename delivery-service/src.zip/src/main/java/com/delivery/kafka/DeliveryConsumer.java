package com.delivery.kafka;

import com.delivery.entity.Delivery;
import com.delivery.repository.DeliveryRepository;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;

@Service
public class DeliveryConsumer {

    private final DeliveryRepository deliveryRepository;

    public DeliveryConsumer(DeliveryRepository deliveryRepository) {
        this.deliveryRepository = deliveryRepository;
    }

    @KafkaListener(topics = "order-topic", groupId = "delivery-service-group")
    public void consume(String message) {
        System.out.println("📦 Received delivery request: " + message);

        Delivery delivery = new Delivery();
        delivery.setOrderId("ORD-" + System.currentTimeMillis());
        delivery.setUserId("USER-123");
        delivery.setProductNames(Arrays.asList("Demo Product"));
        delivery.setTotalAmount(1999.99);
        delivery.setDeliveryDate(LocalDateTime.now().plusDays(3));
        delivery.setStatus("PENDING");

        deliveryRepository.save(delivery);
        System.out.println("✅ Delivery request saved in MongoDB");
    }
}
