package com.delivery.controller;

import com.delivery.entity.Delivery;
import com.delivery.repo.DeliveryRepo;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/deliveries")
public class DeliveryController {

    private final DeliveryRepo deliveryRepo;

    public DeliveryController(DeliveryRepo deliveryRepo) {
        this.deliveryRepo = deliveryRepo;
    }

    @GetMapping
    public List<Delivery> getAllDeliveries() {
        return deliveryRepo.findAll();
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<Delivery> getByOrderId(@PathVariable String orderId) {
        return deliveryRepo.findByOrderId(orderId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
