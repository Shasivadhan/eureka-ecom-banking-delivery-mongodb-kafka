package com.app.bank.dto;

import java.math.BigDecimal;

public class UserResponseDTO {
    private String fullName;
    private String accountNumber;
    private BigDecimal balance;

    // Constructors
    public UserResponseDTO() {}

    public UserResponseDTO(String fullName, String accountNumber, BigDecimal balance) {
        this.fullName = fullName;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Getters & Setters
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
}
