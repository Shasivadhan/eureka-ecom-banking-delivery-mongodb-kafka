
package com.app.bank.service;

import com.app.bank.dto.*;
import com.app.bank.entity.User;
import java.util.List;

public interface BankService {
    UserResponseDTO registerUser(RegistrationRequest request);
    String transferFunds(FundTransferRequest request);
    List<String> getStatement(StatementRequest request);
    String deleteAccountByNumber(String accountNumber);
    String deleteAllAccounts();
    String deposit(DepositRequest request);
    List<User> getAllUsers();




}
