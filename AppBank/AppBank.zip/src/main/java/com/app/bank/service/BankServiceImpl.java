package com.app.bank.service;

import com.app.bank.dto.*;
import com.app.bank.entity.*;
import com.app.bank.repo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;

@Service
public class BankServiceImpl implements BankService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private AccountRepo accountRepo;

    @Autowired
    private TransactionRepo transactionRepo;

    private String generateAccountNumber() {
        return String.valueOf(new Random().nextLong(1000000000L, 9999999999L));
    }

    @Override
    public UserResponseDTO registerUser(RegistrationRequest request) {
        User user = new User();
        user.setFullName(request.getFullName());
        user.setAge(request.getAge());

        Account account = new Account();
        account.setAccountNumber(generateAccountNumber());
        account.setBalance(BigDecimal.valueOf(10000));
        account.setFullName(request.getFullName());

        user.setAccount(account);
        userRepo.save(user);

        return new UserResponseDTO(
                user.getFullName(),
                account.getAccountNumber(),
                account.getBalance()
        );
    }

    @Override
    @Transactional
    public String transferFunds(FundTransferRequest request) {
        Account from = accountRepo.findById(request.getFromAccount())
                .orElseThrow(new java.util.function.Supplier<RuntimeException>() {
                    @Override
                    public RuntimeException get() {
                        return new RuntimeException("From account not found");
                    }
                });

        Account to = accountRepo.findById(request.getToAccount())
                .orElseThrow(new java.util.function.Supplier<RuntimeException>() {
                    @Override
                    public RuntimeException get() {
                        return new RuntimeException("To account not found");
                    }
                });

        BigDecimal amount = request.getAmount();
        if (from.getBalance().subtract(amount).compareTo(BigDecimal.valueOf(5000)) < 0) {
            return "Transfer failed: You Must Maintain Minimum ₹5000 balance in your bank account";
        }

        from.setBalance(from.getBalance().subtract(amount));
        to.setBalance(to.getBalance().add(amount));

        Transaction debit = new Transaction();
        debit.setType("DEBIT");
        debit.setAmount(amount);
        debit.setTimestamp(LocalDateTime.now());
        debit.setAccount(from);
        debit.setDescription("Transferred to " + to.getAccountNumber());

        Transaction credit = new Transaction();
        credit.setType("CREDIT");
        credit.setAmount(amount);
        credit.setTimestamp(LocalDateTime.now());
        credit.setAccount(to);
        credit.setDescription("Received from " + from.getAccountNumber());

        transactionRepo.saveAll(List.of(debit, credit));
        accountRepo.save(from);
        accountRepo.save(to);

        return "Transfer successful.";
    }

    @Override
    public List<String> getStatement(StatementRequest request) {
        YearMonth ym = YearMonth.of(request.getYear(), request.getMonth());
        LocalDateTime start = ym.atDay(1).atStartOfDay();
        LocalDateTime end = ym.atEndOfMonth().atTime(23, 59, 59);

        List<Transaction> txns = transactionRepo.findByAccount_AccountNumberAndTimestampBetween(
                request.getAccountNumber(), start, end);

        List<String> result = new ArrayList<>();
        for (Transaction t : txns) {
            result.add(t.getTimestamp() + " - " + t.getType() + ": ₹" + t.getAmount() + " (" + t.getDescription() + ")");
        }
        return result;
    }

    @Override
    public String deleteAccountByNumber(String accountNumber) {
        Account account = accountRepo.findById(accountNumber)
                .orElseThrow(new java.util.function.Supplier<RuntimeException>() {
                    @Override
                    public RuntimeException get() {
                        return new RuntimeException("Account not found");
                    }
                });

        User user = userRepo.findAll().stream()
                .filter(new java.util.function.Predicate<User>() {
                    @Override
                    public boolean test(User u) {
                        return u.getAccount().getAccountNumber().equals(accountNumber);
                    }
                })
                .findFirst()
                .orElseThrow(new java.util.function.Supplier<RuntimeException>() {
                    @Override
                    public RuntimeException get() {
                        return new RuntimeException("User not found");
                    }
                });

        userRepo.delete(user);
        return "Account " + accountNumber + " deleted.";
    }

    @Override
    public String deleteAllAccounts() {
        userRepo.deleteAll();
        return "All accounts and users deleted.";
    }

    @Override
    public String deposit(DepositRequest request) {
        User user = userRepo.findByAccount_AccountNumber(request.getAccountNumber())
                .orElseThrow(new java.util.function.Supplier<RuntimeException>() {
                    @Override
                    public RuntimeException get() {
                        return new RuntimeException("Account not found");
                    }
                });

        if (request.getAmount() <= 0) {
            throw new IllegalArgumentException("Deposit amount must be greater than zero");
        }

        Account account = user.getAccount();
        BigDecimal depositAmount = BigDecimal.valueOf(request.getAmount());

        account.setBalance(account.getBalance().add(depositAmount));
        accountRepo.save(account);

        Transaction txn = new Transaction();
        txn.setAccount(account);
        txn.setType("CREDIT");
        txn.setAmount(depositAmount);
        txn.setTimestamp(LocalDateTime.now());
        txn.setDescription("Deposit of ₹" + depositAmount);
        transactionRepo.save(txn);

        return "Deposit successful. New balance: ₹" + account.getBalance();
    }

    @Override
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }
}
