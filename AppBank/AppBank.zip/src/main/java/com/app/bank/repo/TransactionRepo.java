
package com.app.bank.repo;

import com.app.bank.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.time.LocalDateTime;

public interface TransactionRepo extends JpaRepository<Transaction, Long> {
    List<Transaction> findByAccount_AccountNumberAndTimestampBetween(String accountNumber, LocalDateTime start, LocalDateTime end);
}
