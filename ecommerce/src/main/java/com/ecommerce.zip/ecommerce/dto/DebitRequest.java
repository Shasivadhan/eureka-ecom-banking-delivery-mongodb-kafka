package com.ecommerce.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DebitRequest {
    private String accountNumber;
    private double amount;
    private String description;
    private Long userId;
}
