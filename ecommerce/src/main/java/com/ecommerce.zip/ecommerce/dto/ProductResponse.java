package com.ecommerce.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor // ✅ Adds no-args constructor (fixes the error)
@AllArgsConstructor // ✅ Optional: if you want constructor with all fields
public class ProductResponse {
    private Long id;
    private String name;
    private String category;
    private BigDecimal price;
    private int stock;

    // ✅ Custom constructor for test data creation (you can keep this)
    public ProductResponse(Long id, String name, BigDecimal price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
}
