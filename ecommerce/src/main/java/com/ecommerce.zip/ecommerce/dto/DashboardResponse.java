package com.ecommerce.dto;

import java.math.BigDecimal;
import java.util.List;

public class DashboardResponse {
    private String month;
    private BigDecimal totalPurchaseAmount;   // <— BigDecimal
    private List<DashboardItem> items;

    public String getMonth() { return month; }
    public void setMonth(String month) { this.month = month; }

    public BigDecimal getTotalPurchaseAmount() { return totalPurchaseAmount; }
    public void setTotalPurchaseAmount(BigDecimal totalPurchaseAmount) { this.totalPurchaseAmount = totalPurchaseAmount; }

    public List<DashboardItem> getItems() { return items; }
    public void setItems(List<DashboardItem> items) { this.items = items; }
}
