package com.ecommerce.controller;

import com.ecommerce.dto.DebitRequest;
import com.ecommerce.dto.PurchaseResponse;
import com.ecommerce.service.OrderService;

import org.slf4j.Logger;                                      // <–– added
import org.slf4j.LoggerFactory;                               // <–– added
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private static final Logger log =
            LoggerFactory.getLogger(OrderController.class);         // <–– added

    @Autowired
    private OrderService orderService;

    @PostMapping("/purchase")
    public ResponseEntity<PurchaseResponse> purchase(@RequestBody DebitRequest request) {
        log.info("Received purchase request: userId={} account={}",   // <–– added
                request.getUserId(), request.getAccountNumber());   // <–– added

        PurchaseResponse response = orderService.purchase(request);

        log.debug("purchase() returned: {}", response);              // <–– added
        return ResponseEntity.ok(response);
    }

    @GetMapping("/dashboard/{userId}")
    public ResponseEntity<?> getMonthlyDashboard(@PathVariable Long userId) {
        log.info("Fetching dashboard for userId={}", userId);       // <–– added

        var dashboard = orderService.getMonthlyDashboard(userId);

        log.debug("dashboard data for userId={}: {}",               // <–– added
                userId, dashboard);                               // <–– added
        return ResponseEntity.ok(dashboard);
    }
}
