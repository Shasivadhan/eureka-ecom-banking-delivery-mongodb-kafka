package com.ecommerce.controller;

import com.ecommerce.dto.CartItemRequest;
import com.ecommerce.entity.CartItem;
import com.ecommerce.service.CartService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private static final Logger log = LoggerFactory.getLogger(CartController.class);

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @PostMapping("/add")
    public String add(@RequestBody CartItemRequest request) {
        String result = cartService.addToCart(request);
        return result; // e.g., "Product added to cart"
    }

    @DeleteMapping("/remove/{id}")
    public String remove(@PathVariable Long id) {
        log.info("Removing cart item with id={}", id);
        cartService.removeFromCart(id);       // service returns void
        return "Item removed from cart";      // controller returns a message
    }

    @GetMapping("/user/{userId}")
    public List<CartItem> getUserCart(@PathVariable Long userId) {
        List<CartItem> items = cartService.getCartItems(userId);
        log.debug("Found {} items in cart for user {}", items.size(), userId);
        return items;
    }

    @DeleteMapping("/user/{userId}")
    public ResponseEntity<String> clearCartByUser(@PathVariable Long userId) {
        log.info("Clearing cart for userId={}", userId);
        cartService.clearCart(userId);        // service returns void
        return ResponseEntity.ok("Cart cleared");
    }
}
