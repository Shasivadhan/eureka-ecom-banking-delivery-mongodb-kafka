package com.ecommerce.service.impl;

import com.ecommerce.dto.DashboardItem;
import com.ecommerce.dto.DashboardResponse;
import com.ecommerce.dto.PurchaseResponse;
import com.ecommerce.dto.DebitRequest;
import com.ecommerce.entity.*;
import com.ecommerce.feign.BankClient;
import com.ecommerce.repository.*;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.CartService;
import com.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired private UserService userService;
    @Autowired private CartService cartService;
    @Autowired private OrderRepo orderRepo;
    @Autowired private OrderItemRepo orderItemRepo;
    @Autowired private BankClient bankClient;
    @Autowired private CartItemRepo cartItemRepo;
    @Autowired private UserRepo userRepo;

    @Override
    public PurchaseResponse purchaseItems(Long userId, String accountNumber) {
        User user = userService.getUserById(userId);
        List<CartItem> cartItems = cartService.getCartItems(userId);

        if (cartItems == null || cartItems.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cart is empty.");
        }

        // Sum with BigDecimal: price * qty
        BigDecimal totalAmount = cartItems.stream()
                .map(ci -> ci.getProduct().getPrice()                                     // Product#getPrice() -> BigDecimal
                        .multiply(BigDecimal.valueOf(ci.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Bank client typically expects a primitive number; convert only here
        DebitRequest request = new DebitRequest();
        request.setAccountNumber(accountNumber);
        request.setAmount(totalAmount.doubleValue());
        request.setDescription("Purchase from E-Commerce");
        bankClient.debitAccount(request);

        // Create and save order
        Order order = new Order();
        order.setUser(user);
        order.setPurchaseDate(LocalDateTime.now());
        order.setTotalAmount(totalAmount);                                               // BigDecimal all the way
        order = orderRepo.save(order);

        // Copy cart -> order items
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cartItems) {
            OrderItem oi = new OrderItem();
            oi.setOrder(order);
            oi.setProduct(cartItem.getProduct());
            oi.setQuantity(cartItem.getQuantity());
            // Alias methods in OrderItem: setPrice(...) maps to priceAtPurchase
            oi.setPrice(cartItem.getProduct().getPrice());
            orderItems.add(oi);
        }
        orderItemRepo.saveAll(orderItems);

        // Clear cart
        cartService.clearCart(userId);

        // Build response (DTOs use BigDecimal)
        PurchaseResponse response = new PurchaseResponse();
        response.setOrderId(order.getId());
        response.setTotalAmount(totalAmount);
        response.setPurchaseDate(order.getPurchaseDate());
        response.setProductNames(orderItems.stream()
                .map(oi -> oi.getProduct().getName())
                .collect(Collectors.toList()));
        response.setMessage("Order placed successfully");
        return response;
    }

    @Override
    public List<DashboardResponse> getMonthlyDashboard(Long userId) {
        User user = userService.getUserById(userId);
        List<Order> orders = orderRepo.findByUser(user);

        Map<YearMonth, List<Order>> grouped = orders.stream()
                .collect(Collectors.groupingBy(o -> YearMonth.from(o.getPurchaseDate())));

        List<DashboardResponse> result = new ArrayList<>();

        for (Map.Entry<YearMonth, List<Order>> entry : grouped.entrySet()) {
            YearMonth ym = entry.getKey();
            List<Order> monthlyOrders = entry.getValue();

            BigDecimal total = BigDecimal.ZERO;                                       // BigDecimal, not double
            Map<String, DashboardItem> itemMap = new LinkedHashMap<>();

            for (Order order : monthlyOrders) {
                List<OrderItem> items = orderItemRepo.findByOrder(order);

                for (OrderItem item : items) {
                    String key = item.getProduct().getName();
                    DashboardItem existing = itemMap.get(key);

                    if (existing != null) {
                        existing.setQuantity(existing.getQuantity() + item.getQuantity());
                    } else {
                        DashboardItem newItem = new DashboardItem();
                        newItem.setName(item.getProduct().getName());
                        newItem.setPrice(item.getPrice());                             // BigDecimal via alias getter
                        newItem.setQuantity(item.getQuantity());
                        itemMap.put(key, newItem);
                    }

                    // total += price * qty (BigDecimal)
                    total = total.add(item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())));
                }
            }

            DashboardResponse dashboard = new DashboardResponse();
            dashboard.setMonth(ym.toString());
            dashboard.setTotalPurchaseAmount(total);                                   // BigDecimal
            dashboard.setItems(new ArrayList<>(itemMap.values()));
            result.add(dashboard);
        }

        return result;
    }

    @Override
    public PurchaseResponse purchase(DebitRequest request) {
        // Validate user
        User user = userRepo.findById(request.getUserId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));

        // Validate cart is not empty
        List<CartItem> cartItems = cartItemRepo.findByUser(user);
        if (cartItems == null || cartItems.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cart is empty");
        }

        // Prepare a simple echo response (use request amount if this path is just for testing)
        PurchaseResponse response = new PurchaseResponse();
        response.setOrderId(500L);                                                     // simulated id for this path
        response.setMessage("Order placed successfully");
        response.setTotalAmount(BigDecimal.valueOf(request.getAmount()));
        response.setPurchaseDate(LocalDateTime.now());
        response.setProductNames(
                cartItems.stream().map(ci -> ci.getProduct().getName()).toList()
        );
        return response;
    }

    @Override
    public void purchase(Long userId, String accountNumber) {
        // Delegate to the main implementation and ignore the return value
        purchaseItems(userId, accountNumber);
    }
}
