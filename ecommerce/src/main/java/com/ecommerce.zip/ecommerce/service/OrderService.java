package com.ecommerce.service;

import com.ecommerce.dto.DebitRequest;
import com.ecommerce.dto.PurchaseResponse;
import com.ecommerce.dto.DashboardResponse;

import java.util.List;

public interface OrderService {
    PurchaseResponse purchaseItems(Long userId, String accountNumber);
    List<DashboardResponse> getMonthlyDashboard(Long userId);

    PurchaseResponse purchase(DebitRequest request);


    void purchase(Long userId, String accountNumber);
}
