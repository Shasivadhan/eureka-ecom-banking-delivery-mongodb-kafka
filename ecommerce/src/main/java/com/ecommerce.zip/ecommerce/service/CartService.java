package com.ecommerce.service;

import com.ecommerce.dto.CartItemRequest;
import com.ecommerce.entity.CartItem;

import java.util.List;

public interface CartService {
    String addToCart(CartItemRequest request);

    /** Primary API */
    List<CartItem> getCartItems(Long userId);

    /** Alias to satisfy tests that call getCartItemsByUserId(...) */
    default List<CartItem> getCartItemsByUserId(Long userId) {
        return getCartItems(userId);
    }

    void clearCart(Long userId);

    void removeFromCart(Long cartItemId);
}
