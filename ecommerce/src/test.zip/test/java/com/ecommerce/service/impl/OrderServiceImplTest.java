package com.ecommerce.service.impl;

import com.ecommerce.dto.DashboardItem;
import com.ecommerce.dto.DashboardResponse;
import com.ecommerce.dto.DebitRequest;
import com.ecommerce.dto.PurchaseResponse;
import com.ecommerce.entity.*;
import com.ecommerce.feign.BankClient;
import com.ecommerce.repository.CartItemRepo;
import com.ecommerce.repository.OrderItemRepo;
import com.ecommerce.repository.OrderRepo;
import com.ecommerce.repository.UserRepo;
import com.ecommerce.service.CartService;
import com.ecommerce.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

    @Mock private UserService userService;
    @Mock private CartService cartService;
    @Mock private OrderRepo orderRepo;
    @Mock private OrderItemRepo orderItemRepo;
    @Mock private BankClient bankClient;
    @Mock private CartItemRepo cartItemRepo;
    @Mock private UserRepo userRepo;

    @InjectMocks
    private OrderServiceImpl orderService;

    private User user;
    private Product product;
    private CartItem cartItem;
    private Order order;

    @BeforeEach
    void setup() {
        user = new User();
        user.setId(1L);
        user.setFullName("Buyer");

        product = new Product();
        product.setId(101L);
        product.setName("Monitor");
        product.setPrice(new BigDecimal("15000.00"));

        cartItem = new CartItem();
        cartItem.setUser(user);
        cartItem.setProduct(product);
        cartItem.setQuantity(2);

        order = new Order();
        order.setId(500L);
        order.setUser(user);
        order.setPurchaseDate(LocalDateTime.now());
        order.setTotalAmount(30000.00);
    }

    @Test
    void testPurchaseItems_Success() {
        // arrange
        when(userService.getUserById(1L)).thenReturn(user);
        when(cartService.getCartItems(1L)).thenReturn(List.of(cartItem));
        when(bankClient.debitAccount(any(DebitRequest.class))).thenReturn("SUCCESS");
        when(orderRepo.save(any(Order.class))).thenAnswer(inv -> {
            Order o = inv.getArgument(0);
            o.setId(500L);
            o.setPurchaseDate(LocalDateTime.now());
            return o;
        });
        when(orderItemRepo.saveAll(anyList())).thenReturn(Collections.emptyList());

        // act
        PurchaseResponse resp = orderService.purchaseItems(1L, "1234567890");

        // assert
        assertNotNull(resp);
        assertEquals(500L, resp.getOrderId());
        assertEquals(30000.00, resp.getTotalAmount(), 0.001);
        assertEquals("Order placed successfully", resp.getMessage());
        assertEquals(List.of("Monitor"), resp.getProductNames());
        assertNotNull(resp.getPurchaseDate());

        verify(bankClient).debitAccount(any(DebitRequest.class));
        verify(orderRepo).save(any(Order.class));
        verify(orderItemRepo).saveAll(anyList());
        verify(cartService).clearCart(1L);
    }

    @Test
    void testPurchaseItems_EmptyCart() {
        when(userService.getUserById(1L)).thenReturn(user);
        when(cartService.getCartItems(1L)).thenReturn(Collections.emptyList());

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> orderService.purchaseItems(1L, "1234567890"));
        assertEquals("Cart is empty.", ex.getMessage());
    }

    @Test
    void testGetMonthlyDashboard_EmptyOrders() {
        when(userService.getUserById(1L)).thenReturn(user);
        when(orderRepo.findByUser(user)).thenReturn(Collections.emptyList());

        var dash = orderService.getMonthlyDashboard(1L);
        assertTrue(dash.isEmpty());
    }

    @Test
    void testPurchase_WithDebitRequest_Success() {
        // arrange
        DebitRequest req = new DebitRequest();
        req.setUserId(1L);
        req.setAccountNumber("ACC123");
        req.setAmount(1234.56);
        req.setDescription("Test");

        when(userRepo.findById(1L)).thenReturn(Optional.of(user));
        when(cartItemRepo.findByUser(user)).thenReturn(List.of(cartItem));

        // act
        PurchaseResponse resp = orderService.purchase(req);

        // assert
        assertNotNull(resp);
        assertEquals(500L, resp.getOrderId());
        assertEquals(req.getAmount(), resp.getTotalAmount());
        assertEquals("Order placed successfully", resp.getMessage());
        assertEquals(List.of("Monitor"), resp.getProductNames());
        assertNotNull(resp.getPurchaseDate());
    }

    @Test
    void testPurchase_Void_Success() {
        // arrange
        when(userService.getUserById(1L)).thenReturn(user);
        when(cartService.getCartItems(1L)).thenReturn(List.of(cartItem));
        when(orderRepo.save(any(Order.class))).thenReturn(order);
        when(orderItemRepo.saveAll(anyList())).thenReturn(Collections.emptyList());

        // act
        assertDoesNotThrow(() -> orderService.purchase(1L, "1234567890"));

        // verify side‐effects
        verify(bankClient).debitAccount(any(DebitRequest.class));
        verify(orderRepo).save(any(Order.class));
        verify(orderItemRepo).saveAll(anyList());
        verify(cartService).clearCart(1L);
    }

    @Test
    void testPurchaseItems_BankError() {
        // arrange
        when(userService.getUserById(1L)).thenReturn(user);
        when(cartService.getCartItems(1L)).thenReturn(List.of(cartItem));
        // simulate bank failure
        when(bankClient.debitAccount(any(DebitRequest.class)))
                .thenThrow(new RuntimeException("Bank declined"));

        // act & assert
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> orderService.purchaseItems(1L, "1234567890"));

        assertEquals("Bank declined", ex.getMessage());

        // verify that we never save an order or clear the cart
        verify(orderRepo, never()).save(any(Order.class));
        verify(cartService, never()).clearCart(anyLong());
    }

    // In OrderServiceImplTest, add:

    @Test
    void testPurchase_WithDebitRequest_UserNotFound() {
        // arrange
        DebitRequest req = new DebitRequest();
        req.setUserId(2L);
        req.setAccountNumber("ACC123");
        req.setAmount(100.0);
        req.setDescription("Test");

        when(userRepo.findById(2L)).thenReturn(Optional.empty());

        // act & assert
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> orderService.purchase(req));
        assertEquals("User not found", ex.getMessage());

        verify(cartItemRepo, never()).findByUser(any());
    }

    @Test
    void testPurchase_WithDebitRequest_EmptyCart() {
        // arrange
        DebitRequest req = new DebitRequest();
        req.setUserId(1L);
        req.setAccountNumber("ACC123");
        req.setAmount(100.0);
        req.setDescription("Test");

        when(userRepo.findById(1L)).thenReturn(Optional.of(user));
        when(cartItemRepo.findByUser(user)).thenReturn(Collections.emptyList());

        // act & assert
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> orderService.purchase(req));
        assertEquals("Cart is empty", ex.getMessage());

        verify(cartItemRepo).findByUser(user);
    }
    @Test
    void testGetMonthlyDashboard_MultipleOrders() {
        // arrange
        when(userService.getUserById(1L)).thenReturn(user);

        // create three orders: two in Jan 2025, one in Feb 2025
        Order jan1 = new Order();
        jan1.setId(100L);
        jan1.setUser(user);
        jan1.setPurchaseDate(LocalDateTime.of(2025, 1, 10, 10, 0));

        Order jan2 = new Order();
        jan2.setId(101L);
        jan2.setUser(user);
        jan2.setPurchaseDate(LocalDateTime.of(2025, 1, 20, 12, 0));

        Order feb1 = new Order();
        feb1.setId(102L);
        feb1.setUser(user);
        feb1.setPurchaseDate(LocalDateTime.of(2025, 2, 5, 15, 0));

        when(orderRepo.findByUser(user))
                .thenReturn(List.of(jan1, jan2, feb1));

        // items for jan1
        OrderItem oiJan1 = new OrderItem();
        oiJan1.setOrder(jan1);
        oiJan1.setProduct(product);              // Monitor @15000×1
        oiJan1.setQuantity(1);
        oiJan1.setPriceAtPurchase(product.getPrice());

        // items for jan2
        Product keyboard = new Product();
        keyboard.setName("Keyboard");
        keyboard.setPrice(new BigDecimal("5000.00"));
        OrderItem oiJan2 = new OrderItem();
        oiJan2.setOrder(jan2);
        oiJan2.setProduct(keyboard);             // Keyboard @5000×2
        oiJan2.setQuantity(2);
        oiJan2.setPriceAtPurchase(keyboard.getPrice());

        // items for feb1
        Product mouse = new Product();
        mouse.setName("Mouse");
        mouse.setPrice(new BigDecimal("2000.00"));
        OrderItem oiFeb1 = new OrderItem();
        oiFeb1.setOrder(feb1);
        oiFeb1.setProduct(mouse);                // Mouse @2000×1
        oiFeb1.setQuantity(1);
        oiFeb1.setPriceAtPurchase(mouse.getPrice());

        when(orderItemRepo.findByOrder(jan1)).thenReturn(List.of(oiJan1));
        when(orderItemRepo.findByOrder(jan2)).thenReturn(List.of(oiJan2));
        when(orderItemRepo.findByOrder(feb1)).thenReturn(List.of(oiFeb1));

        // act
        List<DashboardResponse> dashboards = orderService.getMonthlyDashboard(1L);

        // assert: two months
        assertEquals(2, dashboards.size());

        // map by month string for easy lookup
        Map<String, DashboardResponse> map = dashboards.stream()
                .collect(Collectors.toMap(DashboardResponse::getMonth, dr -> dr));

        // January 2025
        DashboardResponse jan = map.get("2025-01");
        assertNotNull(jan);
        assertEquals(25000.00, jan.getTotalPurchaseAmount(), 0.001);
        // should contain Monitor (1×15000) and Keyboard (2×5000)
        List<DashboardItem> janItems = jan.getItems();
        assertEquals(2, janItems.size());
        DashboardItem mon = janItems.stream()
                .filter(i -> i.getName().equals("Monitor"))
                .findFirst().get();
        assertEquals(1, mon.getQuantity());
        assertEquals(new BigDecimal("15000.00"), mon.getPrice());
        DashboardItem key = janItems.stream()
                .filter(i -> i.getName().equals("Keyboard"))
                .findFirst().get();
        assertEquals(2, key.getQuantity());
        assertEquals(new BigDecimal("5000.00"), key.getPrice());

        // February 2025
        DashboardResponse feb = map.get("2025-02");
        assertNotNull(feb);
        assertEquals(2000.00, feb.getTotalPurchaseAmount(), 0.001);
        List<DashboardItem> febItems = feb.getItems();
        assertEquals(1, febItems.size());
        DashboardItem mou = febItems.get(0);
        assertEquals("Mouse", mou.getName());
        assertEquals(1, mou.getQuantity());
        assertEquals(new BigDecimal("2000.00"), mou.getPrice());
    }



}
