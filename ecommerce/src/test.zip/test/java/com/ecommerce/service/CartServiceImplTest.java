package com.ecommerce.service;

import com.ecommerce.dto.CartItemRequest;
import com.ecommerce.entity.CartItem;
import com.ecommerce.entity.Product;
import com.ecommerce.entity.User;
import com.ecommerce.repository.CartItemRepo;
import com.ecommerce.repository.ProductRepo;
import com.ecommerce.repository.UserRepo;
import com.ecommerce.service.impl.CartServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CartServiceImplTest {

    @Mock
    private CartItemRepo cartItemRepo;

    @Mock
    private ProductRepo productRepo;

    @Mock
    private UserRepo userRepo;

    @InjectMocks
    private CartServiceImpl cartService;

    private CartItemRequest request;
    private User user;
    private Product product;

    @BeforeEach
    public void setup() {
        request = new CartItemRequest();
        request.setUserId(1L);
        request.setProductId(101L);
        request.setQuantity(2);

        user = new User();
        user.setId(1L);
        user.setFullName("Test User");

        product = new Product();
        product.setId(101L);
        product.setName("Keyboard");
        product.setPrice(BigDecimal.valueOf(500));
        product.setStock(10); // Ensure stock is enough
    }

    @Test
    public void testAddToCart_Success() {
        when(userRepo.findById(1L)).thenReturn(Optional.of(user));
        when(productRepo.findById(101L)).thenReturn(Optional.of(product));
        when(cartItemRepo.save(any(CartItem.class))).thenAnswer(invocation -> invocation.getArgument(0));

        String result = cartService.addToCart(request);

        assertEquals("Product added to cart", result);
        verify(cartItemRepo, times(1)).save(any(CartItem.class));
    }

    @Test
    public void testAddToCart_UserNotFound() {
        when(userRepo.findById(1L)).thenReturn(Optional.empty());

        Exception ex = assertThrows(RuntimeException.class, () ->
                cartService.addToCart(request));

        assertEquals("User not found", ex.getMessage());
    }

    @Test
    public void testAddToCart_ProductNotFound() {
        when(userRepo.findById(1L)).thenReturn(Optional.of(user));
        when(productRepo.findById(101L)).thenReturn(Optional.empty());

        Exception ex = assertThrows(RuntimeException.class, () ->
                cartService.addToCart(request));

        assertEquals("Product not found", ex.getMessage());
    }

    @Test
    public void testGetCartItemsByUserId_Empty() {
        when(userRepo.findById(1L)).thenReturn(Optional.of(user));
        when(cartItemRepo.findByUser(user)).thenReturn(List.of());

        assertTrue(cartService.getCartItemsByUserId(1L).isEmpty());
    }

    @Test
    public void testClearCart() {
        when(userRepo.findById(1L)).thenReturn(Optional.of(user));

        cartService.clearCart(1L);

        verify(cartItemRepo, times(1)).deleteByUser(user);
    }
}
