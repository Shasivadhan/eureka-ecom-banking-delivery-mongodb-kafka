package com.ecommerce.controller;

import com.ecommerce.dto.DebitRequest;
import com.ecommerce.dto.PurchaseResponse;
import com.ecommerce.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(OrderController.class)
public class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderService orderService;

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setup() {
        objectMapper = new ObjectMapper();
    }

    @Test
    public void testPurchase_Success() throws Exception {
        DebitRequest request = new DebitRequest();
        request.setUserId(1L);
        request.setAccountNumber("1234567890");
        request.setAmount(100.00);
        request.setDescription("Test Purchase");

        PurchaseResponse mockResponse = new PurchaseResponse();
        mockResponse.setOrderId(500L);
        mockResponse.setTotalAmount(100.00);
        mockResponse.setPurchaseDate(LocalDateTime.of(2025,7,19,17,0));
        mockResponse.setProductNames(Collections.singletonList("Monitor"));
        mockResponse.setMessage("Order placed successfully");

        when(orderService.purchase(any(DebitRequest.class)))
                .thenReturn(mockResponse);

        mockMvc.perform(post("/api/orders/purchase")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.orderId").value(500))
                .andExpect(jsonPath("$.totalAmount").value(100.0))
                .andExpect(jsonPath("$.productNames[0]").value("Monitor"))
                .andExpect(jsonPath("$.message").value("Order placed successfully"));
    }

    @Test
    public void testPurchase_EmptyCart() throws Exception {
        DebitRequest request = new DebitRequest();
        request.setUserId(1L);
        request.setAccountNumber("0000");
        request.setAmount(0.0);
        request.setDescription("Empty Cart");

        when(orderService.purchase(any(DebitRequest.class)))
                .thenThrow(new RuntimeException("Cart is empty"));

        mockMvc.perform(post("/api/orders/purchase")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Cart is empty"));
    }

    @Test
    public void testPurchase_BankDecline() throws Exception {
        DebitRequest request = new DebitRequest();
        request.setUserId(1L);
        request.setAccountNumber("9999");
        request.setAmount(50.0);
        request.setDescription("Bank Error");

        when(orderService.purchase(any(DebitRequest.class)))
                .thenThrow(new RuntimeException("Bank declined"));

        mockMvc.perform(post("/api/orders/purchase")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Bank declined"));
    }

    @Test
    public void testGetMonthlyDashboard_Empty() throws Exception {
        Long userId = 1L;
        when(orderService.getMonthlyDashboard(userId))
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/orders/dashboard/{userId}", userId)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]"));
    }
}
