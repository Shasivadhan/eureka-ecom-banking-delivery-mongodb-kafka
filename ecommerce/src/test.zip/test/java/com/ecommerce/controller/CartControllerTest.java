package com.ecommerce.controller;

import com.ecommerce.dto.CartItemRequest;
import com.ecommerce.entity.CartItem;
import com.ecommerce.service.CartService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CartController.class)
public class CartControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CartService cartService;

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setup() {
        objectMapper = new ObjectMapper();
    }

    @Test
    public void testAddToCart_Success() throws Exception {
        CartItemRequest request = new CartItemRequest();
        request.setUserId(1L);
        request.setProductId(101L);
        request.setQuantity(2);

        when(cartService.addToCart(any(CartItemRequest.class)))
                .thenReturn("Item added to cart");

        mockMvc.perform(post("/api/cart/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(content().string("Item added to cart"));

        verify(cartService).addToCart(any(CartItemRequest.class));
    }

    @Test
    public void testRemoveFromCart_Success() throws Exception {
        when(cartService.removeFromCart(10L))
                .thenReturn("Removed item 10");

        mockMvc.perform(delete("/api/cart/remove/{id}", 10L))
                .andExpect(status().isOk())
                .andExpect(content().string("Removed item 10"));

        verify(cartService).removeFromCart(10L);
    }

    @Test
    public void testGetCartItemsByUserId_Empty() throws Exception {
        when(cartService.getCartItems(1L))
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/cart/user/{userId}", 1L)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().json("[]"));

        verify(cartService).getCartItems(1L);
    }

    @Test
    public void testGetCartItemsByUserId_WithItems() throws Exception {
        CartItem ci = new CartItem();
        ci.setId(5L);
        ci.setQuantity(3);

        when(cartService.getCartItems(2L))
                .thenReturn(List.of(ci));

        mockMvc.perform(get("/api/cart/user/{userId}", 2L)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(5))
                .andExpect(jsonPath("$[0].quantity").value(3));

        verify(cartService).getCartItems(2L);
    }

    @Test
    public void testClearCartByUserId() throws Exception {
        // clearCart returns String, so stub it
        when(cartService.clearCart(3L))
                .thenReturn("ignored");

        mockMvc.perform(delete("/api/cart/user/{userId}", 3L))
                .andExpect(status().isOk())
                .andExpect(content().string("Cart cleared for user: 3"));

        verify(cartService).clearCart(3L);
    }
}
